package com.example.habitandhobby

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button


class Chores : Activity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.chores)
        val set = findViewById<Button>(R.id.btnSave)
        set.setOnClickListener {
            val intent = Intent(this, SmallGoals::class.java)
            // Launch the Activity using the intent
            startActivity(intent)
        }

        val clear = findViewById<Button>(R.id.btnClear)
        clear.setOnClickListener {
            //clear the input
        }

    }
}

