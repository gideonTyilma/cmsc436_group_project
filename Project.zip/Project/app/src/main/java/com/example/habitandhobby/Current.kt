package com.example.habitandhobby

import android.app.Activity
import android.os.Bundle


class Current : Activity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.current)

    }
}

