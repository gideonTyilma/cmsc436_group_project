package com.example.habitandhobby

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.Toast

class Achievement : Activity(){
    private lateinit var listv: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.achievement)

        listv = findViewById(R.id.list_of_achievements)

    }
}

